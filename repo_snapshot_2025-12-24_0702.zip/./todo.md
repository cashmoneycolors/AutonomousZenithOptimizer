# TODO

- [x] Investigate assembly informational version changes occurring during test builds.
- [x] Repository recovery steps executed successfully: git status, git clean, dotnet build, dotnet test.
